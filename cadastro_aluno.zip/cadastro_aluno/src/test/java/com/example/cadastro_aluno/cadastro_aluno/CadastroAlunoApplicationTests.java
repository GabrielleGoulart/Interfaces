package com.example.cadastro_aluno.cadastro_aluno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroAlunoApplicationTests {

	@Test
	void contextLoads() {
	}

}
